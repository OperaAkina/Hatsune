from machine import Pin, PWM
import time

class Keypad4x4:
    KEYMAP = [
        ["1", "2", "3", "A"],
        ["4", "5", "6", "B"],
        ["7", "8", "9", "C"],
        ["*", "0", "#", "D"],
    ]

    def __init__(self, row_pins, col_pins):
        self.rows = [Pin(p, Pin.OUT) for p in row_pins]
        self.cols = [Pin(p, Pin.IN, Pin.PULL_UP) for p in col_pins]
        self._all_rows_high()

    def _all_rows_high(self):
        for r in self.rows:
            r.value(1)

    def scan_once(self):
        for r_idx, r in enumerate(self.rows):
            self._all_rows_high()
            r.value(0)
            time.sleep_ms(2)

            for c_idx, c in enumerate(self.cols):
                if c.value() == 0:
                    self._all_rows_high()
                    return self.KEYMAP[r_idx][c_idx]

        self._all_rows_high()
        return None

    def wait_release(self):
        while True:
            pressed = False
            for r in self.rows:
                self._all_rows_high()
                r.value(0)
                time.sleep_ms(1)
                for c in self.cols:
                    if c.value() == 0:
                        pressed = True
                        break
                if pressed:
                    break
            self._all_rows_high()
            if not pressed:
                return
            time.sleep_ms(10)

class Feedback:
    def __init__(self):
        self.led_g = Pin(25, Pin.OUT)
        self.led_y = Pin(26, Pin.OUT)
        self.led_r = Pin(33, Pin.OUT)
        self.buzzer = PWM(Pin(14, Pin.OUT))
        self.buzzer.duty(0)

    def all_off(self):
        self.led_g.off()
        self.led_y.off()
        self.led_r.off()
        self.buzzer.duty(0)

    def typing(self):
        self.led_y.on()
        time.sleep_ms(60)
        self.led_y.off()

    def ok(self):
        self.all_off()
        self.led_g.on()
        self._beep(1000, 200)
        time.sleep_ms(300)
        self.led_g.off()

    def deny(self):
        self.all_off()
        self.led_r.on()
        for _ in range(2):
            self._beep(800, 150)
            time.sleep_ms(80)
        time.sleep_ms(300)
        self.led_r.off()

    def _beep(self, freq, ms):
        self.buzzer.freq(freq)
        self.buzzer.duty(512)
        time.sleep_ms(ms)
        self.buzzer.duty(0)

class PasswordInput:
    def __init__(self, password="123456", max_len=6):
        self.password = password
        self.max_len = max_len
        self.buf = ""

    def push(self, ch):
        if len(self.buf) < self.max_len:
            self.buf += ch

    def clear(self):
        self.buf = ""

    def submit(self):
        ok = (self.buf == self.password)
        self.buf = ""
        return ok

def read_key_event(keypad, debounce_ms=30):
    k1 = keypad.scan_once()
    if not k1:
        return None
    time.sleep_ms(debounce_ms)
    k2 = keypad.scan_once()
    if k1 != k2:
        return None

    keypad.wait_release()
    return k2

print("=" * 50)
print("基础实验06：密码输入框与编辑规则")
print("*键=清空 | #键=确认  默认密码：123456")
print("=" * 50)

ROW_PINS = [32, 4, 16, 17]
COL_PINS = [0, 12, 2, 15]

keypad = Keypad4x4(ROW_PINS, COL_PINS)
fb = Feedback()
pwd = PasswordInput(password="123456", max_len=6)

while True:
    key = read_key_event(keypad)
    if not key:
        time.sleep_ms(10)
        continue

    if key == "*":
        pwd.clear()
        print("[输入清空]")
        fb.typing()

    elif key == "#":
        print(f"[提交密码]：{pwd.buf}")
        if pwd.submit():
            print("→ 密码正确！")
            fb.ok()
        else:
            print("→ 密码错误！")
            fb.deny()

    elif key in "0123456789":
        pwd.push(key)
        print(f"[当前输入]：{pwd.buf}")
        fb.typing()

    else:
        print(f"[无效按键]：{key}")